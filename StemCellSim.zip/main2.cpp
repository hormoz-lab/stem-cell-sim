/*******************************************
* main.cpp: Infer from simulated data tree *
********************************************/
#include<ctime>
#include<iostream>
#include<random>
#include<iomanip>
#include<fstream>
#include<cstring>
#include<algorithm>
#include<string>
#include<cmath>
#include "StemCellSim.h"

int main(int argc, char * argv[])
{
   //simulation object	
   StemCellSim sim;

   //objects that "manage" output files for posterior
   std::ofstream sFile;		//for param s
   std::ofstream nFile;		//for param n
   std::ofstream NFile;		//for param N
   std::ofstream gFile;		//for param g
   std::ofstream LFile;		//for param L
   std::ofstream trajFile;	//for trajectories
   std::ofstream LTTFile;	//for LTT curves
   std::ofstream distFile;	//holds |LTT(data) - LTT(sim)|
   std::ofstream paramFile;	//holds param if data is simulated

   //output files will have form sFile1.txt, where # depends on argv[]
   std::tuple<std::string, std::string, std::string, std::string,
	       std::string, std::string, std::string, std::string> outputFiles;

   std::get<0>(outputFiles) = "sFile";
   std::get<1>(outputFiles) = "nFile";
   std::get<2>(outputFiles) = "NFile";
   std::get<3>(outputFiles) = "gFile";
   std::get<4>(outputFiles) = "LFile";
   std::get<5>(outputFiles) = "trajFile";
   std::get<6>(outputFiles) = "LTTFile";
   std::get<7>(outputFiles) = "distFile";
   std::string paramString = "paramFile";
   std::string inputDataString = "inputDataFile";

   //add number given by argv[] to files
   for(int i = 0; i < strlen(argv[1]); i++)
   {
   	std::get<0>(outputFiles) += argv[1][i];
   	std::get<1>(outputFiles) += argv[1][i];
   	std::get<2>(outputFiles) += argv[1][i];
   	std::get<3>(outputFiles) += argv[1][i];
   	std::get<4>(outputFiles) += argv[1][i];
   	std::get<5>(outputFiles) += argv[1][i];
   	std::get<6>(outputFiles) += argv[1][i];
   	std::get<7>(outputFiles) += argv[1][i];
   	paramString += argv[1][i];
	inputDataString += argv[1][i];
   }

   //add ".txt"
   std::get<0>(outputFiles) += ".txt";
   std::get<1>(outputFiles) += ".txt";
   std::get<2>(outputFiles) += ".txt";
   std::get<3>(outputFiles) += ".txt";
   std::get<4>(outputFiles) += ".txt";
   std::get<5>(outputFiles) += ".txt";
   std::get<6>(outputFiles) += ".txt";
   std::get<7>(outputFiles) += ".txt";
   paramString += ".txt";
   inputDataString += ".txt";

   //open and close files to clear them from previous run,
   //or create them if they don't exist
   sFile.open(std::get<0>(outputFiles));
   nFile.open(std::get<1>(outputFiles));
   NFile.open(std::get<2>(outputFiles));
   gFile.open(std::get<3>(outputFiles));
   LFile.open(std::get<4>(outputFiles));
   trajFile.open(std::get<5>(outputFiles));
   LTTFile.open(std::get<6>(outputFiles));
   distFile.open(std::get<7>(outputFiles));
   paramFile.open(paramString);
   sFile.close();
   nFile.close();
   NFile.close();
   gFile.close();
   LFile.close();
   trajFile.close();
   LTTFile.close();
   distFile.close();
   paramFile.close();

   //reads LTT curve and parameters from data tree file
   sim.readParamFile(inputDataString);

   //check that we've read in data correctly by printing what we've read
   sim.printData();

   //sample 50,000 points from posterior and print them to their
   //respective files
   for(int i = 0; i < 50000; i++)
   {
	//set epsilon distance to 0.3
	sim.samplePosterior(0.3, 0, outputFiles);

	//tracks number of points accumulated for posterior
	std::cout << i << "\n";
   }

   return 0;
}
