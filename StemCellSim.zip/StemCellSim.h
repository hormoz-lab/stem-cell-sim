/****************
* StemCellSim.h *
****************/
#include<vector>
#include<iostream>
#include<random>
#include<tuple>

class StemCellSim{

   public:

	  //Default constructor for simulation object
	  StemCellSim();

	  //clears dynamically allocated memory
	  ~StemCellSim();

	  //runs WF model w/ specified selection and feedback,
	  //and stores # of mutant cells
	  //over time internally in cloneSize_simulated
	  bool runClonalExpansion(double s, int N, int g, int L, double x);
	
	  //Access private variables
	  double get_s_data();
	  int get_n_data();
	  int get_N_data();
	  int get_g_data();
	  int get_L_data();
	  const int * get_cloneSize_simulated();
	  const int * get_cloneSize_data();
	  const std::vector<double> get_LTT_data();

	  //prints tree data stored internally: In case of real data, prints LTT. In case of
	  //simulated data, prints all parameter values and LTT. By default prints
	  //to cout. If fileName specified, outputs to file with name fileName
	  void printData(std::string fileName = "");

	  //reads tree data and stores LTT curve internally (only used for real data trees)
	  void readDataAndStoreLTT(std::string newickFile, double ageOfIndividual);

	  //reads tree data and stores parameter values and LTT curve internally (only used for simulated data trees)
	  void readParamFile(std::string paramFile);

	  //simulates tree data and stores parameters + LTT curve internally
	  void simulateDataAndStoreObservation(double ageOfIndividual, int numOfLineages, double mutationsAccrued, double model_x);

	  //Simulates trees from model until it finds a tree epsilon close.
	  //Then it prints parameter values that gave rise to that tree in outputFiles
	  void samplePosterior(double eps, double model_x,
                               const std::tuple<std::string, std::string,
                               std::string, std::string, std::string,
                               std::string, std::string, std::string> & outputFiles);

	  //computes and returns epsilon
	  double computeEpsSimAndData();

	  //constructs LTT curve from a random sample of a clonal expansion
	  double generateLTT(double mutationRate);

	  //used for sampling from distributions
	  std::mt19937 & generate();
			
  private:

	  /*******************************************************************************
 	  ********************************************************************************
 	  ** If typeData = 'n', no tree data stored internally in StemCellSim object.   **
	  ** If typeData = 'r', real tree data stored internally in StemCellSim object. **
	  ** If typeData= 's', simulated tree data stored internally in StemCellSim     **
	  ** object.     		       			                        **
	  ********************************************************************************
	  *******************************************************************************/
	  char typeData;
	 
	  /****************************************************
	  *****************************************************
	  ** Each time we call runClonalExpansion() the # of **
	  ** mutant stem cells is saved here. This array is  **
	  ** used to produce LTT curves in generateLTT().    **
	  *****************************************************
	  ****************************************************/
	  int * cloneSize_simulated;

	  /*****************************************************
	  ******************************************************
	  * Disease duration of clonal expansion stored here. **
	  * Holds the size of cloneSize_simulated array.      **
	  ******************************************************
	  *****************************************************/
	  int g_simulated;

          /**************************************************
 	  ***************************************************
 	  ** holds LTT curve constructed by generateLTT(). **		
 	  ***************************************************
 	  **************************************************/
	  std::vector<double> LTT_sim;


	  /******************************************************
	  *******************************************************
 	  ** Tree data are stored internally below. 	       **
	  ** In the case of real data, we only store LTT       **
	  ** curve in LTT_data. The other parameters           **
	  ** are initialized to 0 or nullptr, since those      **
	  ** are unknown.				       **
	  *******************************************************
	  ******************************************************/
	  //age of patient
	  double age;

	  //number of sampled lineages
	  int k;
	
	  //time from present to birth of patient in mutations
	  double mutationsAccrued_data;

	  //number of mutated cells at the final time-point
	  int n_data;

	  //selection parameter
	  double s_data;

	  //total # of stem cells
	  int N_data;

	  //disease duration
	  int g_data;

	  //total # of WF generations
	  int L_data;

	  //holds # of mutated stem cells over time
	  int * cloneSize_data;

	  //holds LTT curve of data tree
	  std::vector<double> LTT_data;


	  /**********************************************************************
	  ***********************************************************************
	  ** object that produces random numbers (for large scale simulations) **
	  ***********************************************************************
	  **********************************************************************/
	  std::mt19937 generator;
};
		  
