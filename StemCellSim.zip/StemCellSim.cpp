/******************
* StemCellSim.cpp *
******************/
#include "StemCellSim.h"
#include<cstdlib>
#include<algorithm>
#include<string>
#include<list>
#include<unordered_set>
#include<fstream>
#include<tuple>
#include<iomanip>
#include<cmath>
#include<random>


unsigned long long rdtsc(){
    unsigned int lo,hi;
    __asm__ __volatile__ ("rdtsc" : "=a" (lo), "=d" (hi));
    return ((unsigned long long)hi << 32) | lo;
}


//Default constructor
StemCellSim::StemCellSim() : generator(rdtsc())
{
	//initialize member variables
	age = 0;
	k = 0;
	s_data = 0;
	N_data = 0;
	g_data = 0;
	L_data = 0;
	typeData = 'n';
	cloneSize_simulated = nullptr;
	cloneSize_data = nullptr;
	g_simulated = 0;
	mutationsAccrued_data = 0;
	n_data = 0;
}


//destructor
StemCellSim::~StemCellSim()
{
	if(cloneSize_data != nullptr)
		delete [] cloneSize_data;

	if(cloneSize_simulated != nullptr)
		delete [] cloneSize_simulated;
}


//WF with specified selection and feedback
bool StemCellSim::runClonalExpansion(double s, int N, int g, int L, double x)
{
	g_simulated = g;

	if(g < 2)
	{
		std::cout << "error in runWF: g must be larger than 1\n";
		return false;
	}


        if(cloneSize_simulated != nullptr)
                delete [] cloneSize_simulated;

        cloneSize_simulated = new int[g];

        cloneSize_simulated[0] = 1;

	//clonal expansion
	for(int i = 0; i < g - 1; i++)
	{
		double sTemp;

		if(x >= 0)
			sTemp = s * pow((1.0 - (static_cast<double>(cloneSize_simulated[i]) - 1.0)/static_cast<double>(N - 1.0)), x);
		else
			sTemp = s * pow((1.0 + (static_cast<double>(cloneSize_simulated[i]) - 1.0)/static_cast<double>(N - 1.0)), -1*x);

		double p = cloneSize_simulated[i] * (sTemp + 1);
		p /= static_cast<double>(N + sTemp * cloneSize_simulated[i]);

		std::binomial_distribution<> distribution(N, p);

		cloneSize_simulated[i + 1] = distribution(generator);
	}

	return true;
}


//returns s from data tree
double StemCellSim::get_s_data()
{
	return s_data;
}


//returns n from data tree
int StemCellSim::get_n_data()
{
	return cloneSize_data[g_data - 1];
}


//returns N from data tree
int StemCellSim::get_N_data()
{
	return N_data;
}


//returns g from data tree
int StemCellSim::get_g_data()
{
	return g_data;
}


//returns L from data tree
int StemCellSim::get_L_data()
{
	return L_data;
}


//returns clone size as a function of time from data tree
const int * StemCellSim::get_cloneSize_data()
{
	return cloneSize_data;
}


//returns clone size as a function of time from clonal expansions in ABC
const int * StemCellSim::get_cloneSize_simulated()
{
	return cloneSize_simulated;
}


//returns LTT curve for trees from clonal expansions in ABC
const std::vector<double> StemCellSim::get_LTT_data()
{
	return LTT_data;
}


//Use this function only to read in patient data
//Converts tree data from newick tree to LTT curve
void StemCellSim::readDataAndStoreLTT(std::string newickFile, double ageOfIndividual)
{
   age = ageOfIndividual;

   //using real data
   typeData = 'r';

   std::ifstream in;

   in.open(newickFile);

   if(!in)
   {
	std::cout << "Error in readDataAndStoreLTT method: Input object in";
	std::cout << " bad state! Exiting program...\n";
	return;
   }

   std::string tree;

   char temp;
   temp = in.get();

   //read newick tree
   while(!in.eof())
   {
	tree += temp;
	temp = in.get();
   }


        std::vector< std::vector<double> > array;

        array.push_back( std::vector<double>() );

        std::string num;

        double avg;

        double lenTree1, lenTree2;

        double keep;

	//apply averaging algorithm and convert to LTT
        for(int i = 0; i < tree.size(); i++)
        {
                if(tree[i] == ':')
                {
                        i++;
                        while(isdigit(tree[i]))
                        {
                                num += tree[i];
                                i++;
                        }

                        array[array.size() - 1].push_back( std::stod(num) );

                        num.clear();

                        --i;

                }

                if(tree[i] == ',')
                {
                        array.push_back( std::vector<double>() );
                }

                if(tree[i] == ')' )
                {
                        lenTree1 = array[ array.size() - 1 ][ array[array.size() - 1].size() - 1 ];
                        lenTree2 = array[ array.size() - 2 ][ array[array.size() - 2].size() - 1 ];

                        avg = (lenTree1 + lenTree2) / 2;

                        for(int j = 0; j < array[array.size() - 1].size(); j++)
                                array[ array.size() - 1][j] *= avg / lenTree1;

                        for(int j = 0; j < array[array.size() - 2].size(); j++)
                                array[ array.size() - 2][j] *= avg / lenTree2;


                        keep = array[ array.size() - 1][ array[ array.size() - 1 ].size() - 1 ];

                        array[ array.size() - 1].pop_back();

                        for(int j = 0; j < array[array.size() - 1].size(); j++)
                                array[ array.size() - 2].push_back( array[ array.size() - 1  ][j] );

                        array.pop_back();

                        i += 2;

                        while(isdigit(tree[i]))
                        {
                                num += tree[i];
                                i++;
                        }

                        array[ array.size() - 1].push_back( keep + std::stod(num) );

                        num.clear();

                        i--;
                }

                if(tree[i] == ';')
                {
                        break;
                }
        }


   if(array.size() != 1)
   {
	std::cout << "malformed LTT in Data.\n";
	return;
   }
  
   LTT_data.clear();

   for(int i = 0; i < array[0].size(); i++)
   {
	LTT_data.push_back(array[0][i]);
   }

   LTT_data.push_back(0);

   std::sort(LTT_data.begin(), LTT_data.end());

   mutationsAccrued_data = LTT_data[LTT_data.size() - 1];

   LTT_data.pop_back();

   k = LTT_data.size();
}


//Use function only for simulated tree data
//Reads parameters and LTT curve from simulated tree data
//Parameters read in are generally not used by other
//functions, but kept in case the user decides
//to use them.
void StemCellSim::readParamFile(std::string paramFile)
{
  std::ifstream in;
  in.open(paramFile);

  if(!in)
  {
	std::cout << "Error in readParamFile(): ifstream object in bad state. Exiting function ... \n";
	return;
  }

  std::string str;
  
  std::vector<std::string> p;

  for(int i = 0; i < 10; i++)
  {
	p.push_back("");
  }

  int track = 0;
  int iter = 0;
  while(std::getline(in, str))
  {
	if(iter == 2)
	{
		++iter;
		continue;
	}
	else if(iter == 6)
	{
		for(int i = 6; i < str.size(); i++)
			p[track] += str[i]; 

		age = std::stod(p[track]);
	}
	else if(iter < 8 || iter == 10)
	{
		if(iter != 10)
		{
			for(int i = 4; i < str.size(); i++)
				p[track] += str[i]; 
		}
		else
		{
			for(int i = 18; i < str.size(); i++)
				p[track] += str[i]; 
		}

		if(track == 0)
			g_data = std::stod(p[track]);
		else if(track == 1)
			L_data = std::stod(p[track]);
		else if(track ==2)
			N_data = std::stod(p[track]);
		else if(track == 3)
			n_data = std::stod(p[track]);
		else if(track == 4)
			s_data = std::stod(p[track]);
		else if(track == 6)
			k = std::stod(p[track]);
		else if(track == 9)
		{
			mutationsAccrued_data = std::stod(p[track]);
		}
		
	}
	else if(iter == 8)
	{
		if(cloneSize_data != nullptr)
			delete [] cloneSize_data;

		cloneSize_data = new int[g_data];
		
		std::string tempString = "";
		
		int countParse = 0;
		for(int i = 12; i < str.size(); i++)
		{
			if(str[i] != ',')
			{
				tempString += str[i];
			}
			else
			{
				cloneSize_data[countParse] = static_cast<int>(std::stod(tempString));
				tempString = "";
				++countParse;
			}
		}
	}
	else if(iter == 9)
	{
		LTT_data.clear();
		LTT_data.push_back(0);
		
		std::string tempString = "";
		
		int countParse = 0;
		for(int i = 5; i < str.size(); i++)
		{
			if(str[i] != ',')
			{
				tempString += str[i];
			}
			else
			{
				LTT_data.push_back(std::stod(tempString));
				tempString = "";
				++countParse;
			}
		}
	}

	++track;
	++iter;
  }

  typeData = 's';

  in.close();

  return;
}


//Simulates data and stores parameter values + LTT curve internally
//Uses age to determine number of generations using 1 cell division per year with Gaussian noise
//Uses mutationsAccrued/(L - 1) for mutation rate
void StemCellSim::simulateDataAndStoreObservation(double ageOfIndividual, int numOfLineages, double mutationsAccrued, double model_x)
{
   k = numOfLineages;
   typeData = 's';
   age = ageOfIndividual;

   double s;
   int n;
   double N;
   int g;
   int L;
   double WFmean = age + 1.0;
   double WFstd = (age + 1.0) * 5.0/35.0;


   /************************************************************
   * Change code below to simulate data with fixed             *
   * parameter values or different priors. To fix parameters,  *
   * for example, replace s = s_distr(generator) with s = 0.6; *
   ************************************************************/

   std::uniform_real_distribution<double> saturation(1, 9);
   std::uniform_real_distribution<double> s_distr(0, 2.0);
   std::normal_distribution<double> L_distr(WFmean, WFstd);

   s = s_distr(generator);
   do{
  	do
	{
		L = std::round(L_distr(generator));
	}while(L < 2);
	N = std::round(std::pow(10.0, saturation(generator)));
	g = generator() % static_cast<int>(L - 1) + 2;

	runClonalExpansion(s, N, g, L, model_x);

	n = cloneSize_simulated[g - 1];
   }while(n < k);

  L_data = L;
  g_data = g;
  mutationsAccrued_data = generateLTT(mutationsAccrued/(L - 1.0));

  //initialize all internal data
  s_data = s;
  n_data = n;
  N_data = N;
  LTT_data = LTT_sim;

  if(cloneSize_data != nullptr)
	delete [] cloneSize_data;

  cloneSize_data = new int[g_data];
 
  for(int i = 0; i < g_data; i++)
  {
	cloneSize_data[i] = cloneSize_simulated[i];
  }

  //clear simulation variables
  if(cloneSize_simulated != nullptr)
  {
  	delete [] cloneSize_simulated;
	cloneSize_simulated = nullptr;
  }

  g_simulated = 0;
  LTT_sim.clear();
}


//Prints internally stored data to a file
//(including parameter values if data is simulated)
//If no filename tossed in, just prints with cout as default
void StemCellSim::printData(std::string fileName)
{
   if(fileName == "")
   {
 	std::cout << "g = " << g_data << "\n";
 	std::cout << "L = " << L_data << "\n";
 	std::cout << "g/L = " << static_cast<double>(g_data) / L_data << "\n";
 	std::cout << "N = " << N_data << "\n";
 	std::cout << "n = " << n_data << "\n";
	std::cout << "s = " << s_data << "\n";
	std::cout << "age = " << age << "\n";
	std::cout << "k = " << k << "\n";
 	std::cout << "trajectory: ";
	
	if(cloneSize_data == nullptr)
		std::cout << "nullptr";
	else
	{
 		for(int i = 0; i < g_data; i++)
 		{
 		      std::cout << cloneSize_data[i] << ",";
 		}
	}

	 std::cout << "\n";
	 std::cout << "LTT: ";
	
	 for(int i = 0; i < k; i++)
	 {
	       std::cout << LTT_data[i] << ",";
	 }
	
	 std::cout << "\n";

	 std::cout << "mutationsAccrued: " << mutationsAccrued_data << "\n";
	
	 return;	
   }

   std::ofstream printFile;
   printFile.open(fileName);

   if(!printFile)
   {
	std::cout << "printFile in bad state: check printData function ...\n";
	return;
   }

   if(typeData == 's')
   {
 	std::cout << "g = " << g_data << "\n";
 	std::cout << "L = " << L_data << "\n";
 	std::cout << "g/L = " << static_cast<double>(g_data) / L_data << "\n";
 	std::cout << "N = " << N_data << "\n";
 	std::cout << "n = " << n_data << "\n";
	std::cout << "s = " << s_data << "\n";
	std::cout << "age = " << age << "\n";
	std::cout << "k = " << k << "\n";
 	std::cout << "trajectory: ";
 	for(int i = 0; i < g_data; i++)
 	{
 	      std::cout << cloneSize_data[i] << ",";
 	}

	 std::cout << "\n";
	 std::cout << "LTT: ";
	
	 for(int i = 0; i < k; i++)
	 {
	       std::cout << LTT_data[i] << ",";
	 }
	
	 std::cout << "\n";

	 std::cout << "mutationsAccrued: " << mutationsAccrued_data << "\n";
	

	 printFile << "g = " << g_data << "\n";
	 printFile << "L = " << L_data << "\n";
	 printFile << "g/L = " << static_cast<double>(g_data) / L_data << "\n";
	 printFile << "N = " << N_data << "\n";
	 printFile << "n = " << n_data << "\n";
	 printFile << "s = " << s_data << "\n";
	 printFile << "age = " << age << "\n";
	 printFile << "k = " << k << "\n";

 	 printFile << "trajectory: ";
	 for(int i = 0; i < g_data; i++)
	 {
	       printFile << cloneSize_data[i] << ",";
	 }

	 printFile << "\n";
	
	 printFile << "LTT: ";
	 for(int i = 1; i < k; i++)
	 {
	       printFile << LTT_data[i] << ",";
	 }

	 printFile << "\n";

	 printFile << "mutationsAccrued: " << mutationsAccrued_data << "\n";
   }
   else if(typeData == 'r')
   {
	for(int i = 1; i < k; i++)
	{
	      std::cout << LTT_data[i] << ",";
	}
	std::cout << "\n";

	for(int i = 1; i < k; i++)
	{
	      printFile << LTT_data[i] << ",";
	}
	
	printFile << "\n";
   }

   printFile.close();
}


//Called after running a clonal expansion. Constructs LTT curve from
//a random sample and stores internally as LTT_sim. Returns length of tree
//(length from present to birth of patient in mutations).
double StemCellSim::generateLTT(double mutationRate)
{
	int g = g_simulated;

	if(k > cloneSize_simulated[g - 1] || k < 2)
	{
                std::cout << "ERROR in printPhyTree method";
	}

        int noError = -1;

        int size = k;


        int count = k;

        int find;
        int countLineages;
        double avg;
        int endM;
        int endN;
        int holdM = 0;
        int holdN = 0;
        double holdTopM;
        double holdTopN;
        double subTreeM;
        double subTreeN;
	double holdMutationalLength;
        
	std::poisson_distribution<int> noise(mutationRate);

        std::vector< std::vector<double> > LTTTimes;
        for(int i = 0; i < k; i++)
                LTTTimes.push_back( std::vector<double>(1,0) );


	//Simulate geneological history, adding mutations and
	//averaging simultaneously. The result is an LTT curve
        for(int i = g - 1; i > 0; i--)
        {
                for(int m = 0; m < k; m++)
                {
                        if(!LTTTimes[m].empty())
                        {
                                ++LTTTimes[m][0];
                        }
                }


                count = 1;

                for(int j = 1; j < size; j++)
                {
			double p = count/static_cast<double>(cloneSize_simulated[i - 1]);
                        std::bernoulli_distribution collision(p);

                        if(!collision(generator))
                        {
                                count++;
                        }
                        else
                        {
                                find = generator() % count + 1;

                                countLineages = 0;

                                holdM = 0;
                                holdN = 0;

                                for(int m = 0; m < k; m++)
                                {
                                        if(!LTTTimes[m].empty())
                                        {
                                                ++countLineages;

                                        	if(countLineages == find)
                                        	{
                                                	holdM = m;
                                        	}

                                        	if(countLineages == count + 1)
                                        	{
                                        	        holdN = m;
                                       		}
					}
                                }


                                endM = LTTTimes[holdM].size() - 1;
                                endN = LTTTimes[holdN].size() - 1;

                                if(endM == 0)
                                        subTreeM = 0;
                                else
                                        subTreeM = LTTTimes[holdM][endM];

                                if(endN == 0)
                                        subTreeN = 0;
                                else
                                        subTreeN = LTTTimes[holdN][endN];


				holdTopM = 0;
				holdTopN = 0;

				//add poissonian noise
				for(int b = 0; b < LTTTimes[holdM][0]; b++)
                                	holdTopM += noise(generator);

				//add poissonian noise
				for(int b = 0; b < LTTTimes[holdN][0]; b++)
                                	holdTopN += noise(generator);

                                avg = static_cast<double>( subTreeM + holdTopM + subTreeN + holdTopN ) / 2.0;

                           for(int m = 1; m < LTTTimes[holdM].size(); m++)
                           {
                                        if( subTreeM + holdTopM != 0)
                                                LTTTimes[holdM][m] *= avg / ( subTreeM + holdTopM);
                           }

                           for(int m = 1; m < LTTTimes[holdN].size(); m++)
                           {
                                        if( subTreeN + holdTopN != 0)
                                                LTTTimes[holdN][m] *= avg / ( subTreeN + holdTopN);
                           }

                           for(int m = 1; m < LTTTimes[holdN].size(); m++)
                           {
                                        LTTTimes[holdM].push_back(LTTTimes[holdN][m]);
                           }

                           LTTTimes[holdM].push_back(avg);

                           LTTTimes[holdN].clear();

                           LTTTimes[holdM][0] = 0;
                        }
                }

                size = count;

		//add in remain mutations from the MRCA of the sample to the first generation
		//which corresponds to the birth of the patient.
		if(size == 1)
		{
			std::poisson_distribution<int> noise2((i-1 + L_data - g_data)*mutationRate);
			holdMutationalLength = noise2(generator);

			break;
		}
        }

	//put zero to ensure no top tree mutations left over
	LTTTimes[0][0] = 0;

	LTT_sim.clear();

        LTT_sim.resize(LTTTimes[0].size());

        for(int m = 0; m < LTTTimes[0].size(); m++)
        {
		LTT_sim[m] = LTTTimes[0][m];
        }

        std::sort(LTT_sim.begin(), LTT_sim.end());
	
	holdMutationalLength += LTT_sim[k - 1];
	
	return holdMutationalLength;
}


//Samples a point from posterior distribution using ABC by sampling parameter values
//from prior, simulating clonal expansions, and constructing LTT curves until it finds an
//LTT curve that is sufficiently close to data, and then ends after printing the
//parameter values to their respective files.
void StemCellSim::samplePosterior(double eps, double model_x,
				  const std::tuple<std::string, std::string,
				  std::string, std::string, std::string,
				  std::string, std::string, std::string> & outputFiles)
{
	//If no data has been imported, exit
	if(LTT_data.size() == 0 || typeData == 'n')
	{
		std::cout << "No Data. Leaving samplePosterior() ... ";
		return;
	}

	//declare parameter values for simulation
	double s;
	int n;
	double N;
	int g;
	double L;
	double epsilon = 0;
	double WFmean = age + 1.0;
	double WFstd = (age + 1.0) * 5.0/35.0;

	//used to generate selection param uniformly
	std::uniform_real_distribution<double> saturation(1, 9);
	std::uniform_real_distribution<double> s_distr(0, 2.0);
	std::normal_distribution<double> L_distr(WFmean, WFstd);

	//will store LTT curve from simulation
	do{
		s = s_distr(generator);
		do{
			//get parameter values from priors
			do
			{
				L = std::round(L_distr(generator));
			}while(L < 2);
			N = std::round(std::pow(10.0, saturation(generator)));
			g = generator() % static_cast<int>(L - 1) + 2;

			//run clonal expansion
			runClonalExpansion(s, N, g, L, model_x);
	
			//use to check final clone size for condition
			n = cloneSize_simulated[g - 1];

		}while(n < k);
	
		//compute mutation rate empirically and construct LTT from
		//clonal expansion
		generateLTT(mutationsAccrued_data/(L - 1.0));

		//compute epsilon distance between data LTT and ABC LTT
		epsilon = computeEpsSimAndData();

	//keep parameter values and continue if epsilon is small enough.
	//Else, redraw parameters and simulate again.
	}while(epsilon >= eps);

	//print parameter values kept from ABC to corresponding text files
	std::ofstream sFile;
	std::ofstream nFile;
	std::ofstream NFile;
	std::ofstream gFile;
	std::ofstream LFile;
	std::ofstream trajFile;
	std::ofstream LTTFile;
	std::ofstream distFile;

        sFile.open(std::get<0>(outputFiles), std::ios_base::app);
        nFile.open(std::get<1>(outputFiles), std::ios_base::app);
        NFile.open(std::get<2>(outputFiles), std::ios_base::app);
        gFile.open(std::get<3>(outputFiles), std::ios_base::app);
        LFile.open(std::get<4>(outputFiles), std::ios_base::app);
        trajFile.open(std::get<5>(outputFiles), std::ios_base::app);
        LTTFile.open(std::get<6>(outputFiles), std::ios_base::app);
        distFile.open(std::get<7>(outputFiles), std::ios_base::app);

        sFile << s << ",";
        nFile << n << ",";
        NFile << N << ",";
        gFile << g<< ",";
        LFile << L << ",";

        for(int j = 0; j < g; j++)
                trajFile << cloneSize_simulated[j] << ",";
        trajFile << "\n";

        for(int j = 1; j < LTT_sim.size(); j++)
                LTTFile << LTT_sim[j] << ",";
        LTTFile << "\n";

        distFile << epsilon << ",";

        sFile.close();
        nFile.close();
        NFile.close();
        gFile.close();
        LFile.close();
        trajFile.close();
        LTTFile.close();
        distFile.close();

	return;
}


//Computes epsilon distance between LTT from data and LTT from ABC.
double StemCellSim::computeEpsSimAndData()
{
        int counterSim = 1;
        int counterData = 1;
        double temp = 0;
        double holdSum = 0;

	//note k - counterSim + 1 always reflects number of lineages in existence immeiately b4 that coalescence
        do
        {
                if(counterData != k && counterSim != k)
                {

			//out of two coalescent events, find smaller of the two b.c. the area we are adding to is immediately b4 the "earlier" one
                        if(LTT_sim[counterSim] < LTT_data[counterData])
                        {
				//find "larger" of the two prior coalescent events b.c. we are, again, adding area immediately b4
                                if(LTT_sim[counterSim - 1] > LTT_data[counterData - 1])
                                        temp = static_cast<double>( (k - counterSim + 1) - (k - counterData + 1) ) * (LTT_sim[counterSim] - LTT_sim[counterSim - 1]);
                                else
                                        temp = static_cast<double>( (k - counterSim + 1) - (k - counterData + 1) ) * (LTT_sim[counterSim] - LTT_data[counterData - 1]);

                                        ++counterSim;
                        }
                        else
                        {
                                if(LTT_sim[counterSim - 1] > LTT_data[counterData - 1])
                                        temp = static_cast<double>( (k - counterSim + 1) - (k - counterData + 1) ) * (LTT_data[counterData] - LTT_sim[counterSim - 1]);
                                else
                                        temp = static_cast<double>( (k - counterSim + 1) - (k - counterData + 1) ) * (LTT_data[counterData] - LTT_data[counterData - 1]);


                                ++counterData;

				//note that we incremented counterData b4
                                if(LTT_sim[counterSim] == LTT_data[counterData - 1])
                                        ++counterSim;
                        }
                }
                else if(counterData == k && counterSim != k) //this means counterData has collapsed to 0 lineages (so imagine "pointer" is at top of tree (so it's always largest ptr)
                {

                                if(LTT_sim[counterSim - 1] > LTT_data[counterData - 1])
                                        temp = static_cast<double>( (k - counterSim + 1) - (k - counterData + 1) ) * (LTT_sim[counterSim] - LTT_sim[counterSim - 1]);
                                else
                                        temp = static_cast<double>( (k - counterSim + 1) - (k - counterData + 1) ) * (LTT_sim[counterSim] - LTT_data[counterData - 1]);

                                        ++counterSim;
                }
               else if(counterData != k && counterSim == k)
                {
                                if(LTT_sim[counterSim - 1] > LTT_data[counterData - 1])
                                        temp = static_cast<double>( (k - counterSim + 1) - (k - counterData + 1) ) * (LTT_data[counterData] - LTT_sim[counterSim - 1]);
                                else
                                        temp = static_cast<double>( (k - counterSim + 1) - (k - counterData + 1) ) * (LTT_data[counterData] - LTT_data[counterData - 1]);

                                ++counterData;
                }

                if(temp < 0)
                        temp = 0 - temp;

                holdSum += temp / static_cast<double>(k * LTT_data[LTT_data.size() - 1]);

                if(counterData == k && counterSim == k)
                        break;

        }while(true);

	//returns epsilon
        return holdSum;
}


//used when sampling points from a distribution
std::mt19937 & StemCellSim::generate()
{
	return generator;
}
