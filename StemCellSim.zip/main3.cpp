/************************************
* main.cpp: Infer from patient data *
************************************/
#include<ctime>
#include<iostream>
#include<random>
#include<iomanip>
#include<fstream>
#include<cstring>
#include<algorithm>
#include<string>
#include<cmath>
#include "StemCellSim.h"

int main(int argc, char * argv[])
{
   //simulation object
   StemCellSim sim;

   //objects that "manage" output files for posterior
   std::ofstream sFile;		//for param s
   std::ofstream nFile;		//for param n
   std::ofstream NFile;		//for param N
   std::ofstream gFile;		//for param g
   std::ofstream LFile;		//for param L
   std::ofstream trajFile;	//for trajectories
   std::ofstream LTTFile;	//for LTT curves
   std::ofstream distFile;	//holds |LTT(data) - LTT(sim)|
   std::ofstream paramFile;	//holds param if data is simulated

   //output files will have form sFile1.txt, where # depends on argv[]
   std::tuple<std::string, std::string, std::string, std::string,
	       std::string, std::string, std::string, std::string> outputFiles;

   std::get<0>(outputFiles) = "sFile";
   std::get<1>(outputFiles) = "nFile";
   std::get<2>(outputFiles) = "NFile";
   std::get<3>(outputFiles) = "gFile";
   std::get<4>(outputFiles) = "LFile";
   std::get<5>(outputFiles) = "trajFile";
   std::get<6>(outputFiles) = "LTTFile";
   std::get<7>(outputFiles) = "distFile";
   std::string paramString = "paramFile";
   std::string inputDataString = "inputDataFile";

   //add number given by argv[] to files
   for(int i = 0; i < strlen(argv[1]); i++)
   {
   	std::get<0>(outputFiles) += argv[1][i];
   	std::get<1>(outputFiles) += argv[1][i];
   	std::get<2>(outputFiles) += argv[1][i];
   	std::get<3>(outputFiles) += argv[1][i];
   	std::get<4>(outputFiles) += argv[1][i];
   	std::get<5>(outputFiles) += argv[1][i];
   	std::get<6>(outputFiles) += argv[1][i];
   	std::get<7>(outputFiles) += argv[1][i];
   	paramString += argv[1][i];
	inputDataString += argv[1][i];
   }

   //add ".txt"
   std::get<0>(outputFiles) += ".txt";
   std::get<1>(outputFiles) += ".txt";
   std::get<2>(outputFiles) += ".txt";
   std::get<3>(outputFiles) += ".txt";
   std::get<4>(outputFiles) += ".txt";
   std::get<5>(outputFiles) += ".txt";
   std::get<6>(outputFiles) += ".txt";
   std::get<7>(outputFiles) += ".txt";
   paramString += ".txt";
   inputDataString += ".txt";

   //open and close files to create or clear
   sFile.open(std::get<0>(outputFiles));
   nFile.open(std::get<1>(outputFiles));
   NFile.open(std::get<2>(outputFiles));
   gFile.open(std::get<3>(outputFiles));
   LFile.open(std::get<4>(outputFiles));
   trajFile.open(std::get<5>(outputFiles));
   LTTFile.open(std::get<6>(outputFiles));
   distFile.open(std::get<7>(outputFiles));
   paramFile.open(paramString);
   sFile.close();
   nFile.close();
   NFile.close();
   gFile.close();
   LFile.close();
   trajFile.close();
   LTTFile.close();
   distFile.close();
   paramFile.close();

   //Read data tree for patient with age 34 from Newick file
   sim.readDataAndStoreLTT("tree34cancerous.txt",34);

   //Show resulting LTT converted from Newick 
   sim.printData();

   //sample 50,000 points from posterior
   for(int i = 0; i < 50000; i++)
   {
	sim.samplePosterior(0.03, 0, outputFiles);
	std::cout << i << "\n";
   }

   return 0;
}
