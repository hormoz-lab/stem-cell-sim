/***********************************
* main.cpp: Simulate 30 data trees *
***********************************/
#include "StemCellSim.h"

int main()
{
   //declare StemCellSim object for simulation
   StemCellSim sim;

   //simulate 100 trees as data and print data files
   for(int i = 1; i <= 30; i++)
   {
	std::string inputDataString = "inputDataFile";
	inputDataString += std::to_string(i);
	inputDataString += ".txt";

	//simulate data using feedback x = 30
   	sim.simulateDataAndStoreObservation(34, 22, 723, 30);

   	sim.printData(inputDataString);
   }

   return 0;
}
